clear
Table=load('Full_network_p11_2500.csv');
p=11;
%define step size
delta=1/(p-1);

list_of_indices=0;
Table(1,:)=[];
number_of_max_distances=50;


%the distances between trajectories i jis calculated by pdist.
%to get the ditstances ina matrix form, we use 'squareform'
%then the distance between trajectories i and jare given in position (i,j) in the
%table Distance_tables produced from pdist function 
Distance_tables=pdist(Table);
Distance_tables=squareform(Distance_tables);
%calculate the distance from each point as the sum of euclidean distances
%from that point to all other points. I.e. row 1 summed is that for point 1
Distance_tables_per_row=sum(Distance_tables,2);

s=maxk(Distance_tables_per_row,number_of_max_distances);
collection=0;
%Distance_tables=squareform(Distance_tables);
[m,n]=size(Distance_tables);

for i=1:length(s)
    for j=1:length(Distance_tables_per_row)
        if  Distance_tables_per_row(j)==s(i)
             collection=vertcat(collection, j);
        end
    end
    
end
   
    
    
  %  for j=1:m
   %     for k=1:n
    %        if Distance_tables(j,k)==s(i)
     %           collection=vertcat(collection, [j,k]);
      %      end
       % end
    %end

collection(1,:)=[];
%row_of_indices=vertcat(collection(:,1),collection(:,2));


MAX_traj=Table(collection,:);

csvwrite('Max_distances.csv',MAX_traj);
%MAX_traj(:,19:31)=[];
set_of_base_vectors=MAX_traj(:,1:18);
[A1,B1]=size(MAX_traj);
num_parameters=B1;


a1=0; a2=20;%AUXp_range=[0 50];
b1=0; b2=20;%Fa=[0 20];
c1=0.01; c2=20;%CKp=[0.1 0.5];
d1=0; d2=20;%TDIF=[0 10];%constant amount of TDIF supplied/existing in the TDIF
e1=0; e2=20;%  d_Aux generally the value had before but analysis doesn't run with it  
f1=0; f2=20; % d_PIN %auxin active transport
g1=0; g2=20;%d_MP  
h1=0; h2=20;%d_CK
i1=0;i2=20;%d_PXY_in
j1=0; j2=20;%d_PXY_a
k1=0; k2=20;%r1
l1=0; l2=20;% r2 
m1=0; m2=20;%r3 
n1=0; n2=20;%r4 
o1=0; o2=20;%r5
p1=0; p2=20;%r6
q1=0; q2=20;%r7
r1=0; r2=20;%r8
number_of_trajectories=number_of_max_distances;
 Cells_of_traj = cell(number_of_trajectories, 1) ;
upper_ranges=[a2 b2 c2 d2 e2 f2 g2 h2 i2 j2 k2 l2 m2 n2 o2 p2 q2 r2];


  
Table_width=num_parameters;
 Table_for_printing=zeros(Table_width, 1)';
 
Matrix_of_trajectories=zeros(Table_width, 1)';
[Cells_of_traj]=Create_trajectories_from_scaled_vectors(upper_ranges, delta,number_of_trajectories,num_parameters, set_of_base_vectors,Cells_of_traj);

 for i=1:number_of_trajectories
  
    Matrix_of_trajectories=vertcat(Matrix_of_trajectories, Cells_of_traj{i});
 end
 
 
 
 %for reduced network we delete columns  4, 9, 10, 12, 13, 14 
 
%Matrix_of_trajectories(:,4)=0;
% Matrix_of_trajectories(:,9)=0;
  % Matrix_of_trajectories(:,10)=0;
   % Matrix_of_trajectories(:,12)=0;
    % Matrix_of_trajectories(:,13)=0;
      %    Matrix_of_trajectories(:,14)=0;
%Matrix_of_trajectories=unique(Matrix_of_trajectories, 'rows');
 %note that 'unique' orders tables so I removed it for the actual
 %sensitivity
  csvwrite('Trajectories_p11_50_longest_full.csv', Matrix_of_trajectories);
 
 